# LoanRepo

Runs a floating-rate Indian home loan through the actual RBI repo rate history, reset by reset, and shows what the rate cycle did to its tenure and balance. No lender affiliation, no commission, descriptive rather than prescriptive.

The app is a single self-contained page. `LoanRepo.dc.html` carries the UI and the amortization engine; the engine works with no backend at all, falling back to a bundled copy of the rate history.

## Files

| Path | What it is |
| --- | --- |
| `LoanRepo.dc.html` | The whole app — four screens plus saved runs, and the engine |
| `_ds/industry-…/` | The Industry design system — tokens, component classes, bundle. Linked, not forked |
| `supabase-config.js` | Your project URL and anon key — fill these in |
| `supabase-client.js` | The data layer. Exposes `window.LoanRepoDB` |
| `supabase/migrations/0001_init.sql` | Tables, constraints, RLS policies |
| `supabase/seed.sql` | The 13 MPC rate decisions and 5 published examples |

## Setup

1. Create a Supabase project.
2. Run the schema and seed:

   ```bash
   supabase link --project-ref <ref>
   supabase db push                     # applies supabase/migrations
   psql "$DATABASE_URL" -f supabase/seed.sql
   ```

   Or paste both files into the SQL editor, migration first.

3. Put your URL and **anon public** key into `supabase-config.js`. The anon key is meant to be public — RLS is what protects the data. Never put the `service_role` key in a client file.

4. For Google sign-in: Supabase → Authentication → Providers → Google, add your OAuth client, and add the page's URL to **Redirect URLs**. Magic links need no extra provider setup, but the same URL must be allowed.

Open `LoanRepo.dc.html`. With the config blank the app runs fully client-side; with it filled in, auth, saved runs, the rate table, the examples library, the waitlist and analytics all come alive.

## Data model

- **`repo_rates`** — the MPC decision history. Public read, writes are service-role only. The app reads this at load and falls back to its bundled copy if the table is empty or unreachable, so a bad deploy never breaks the calculator.
- **`examples`** — the case-study library. Public read of `published = true`; unpublished rows are invisible to the anon key. Add a row, flip `published`, and it appears in the Examples table computed live.
- **`loan_runs`** — a borrower's saved calculation: the particulars plus a `result` snapshot of the verdict at save time. Strictly owner-scoped in all four directions (select/insert/update/delete all gated on `auth.uid() = user_id`).
- **`waitlist`** — insert-only for everyone, unreadable through the anon key.
- **`usage_events`** — insert-only, unreadable through the anon key. Screen views and a `run_saved` event carrying only the benchmark. Loan amounts are never sent here.
- **`profiles`** — created by an `on_auth_user_created` trigger; owner read/update only.

## Privacy stance

The calculation happens in the browser. Particulars leave it only when a signed-in user presses **Save this run to my account**, and only that account can read them back. The page says this in those words on the hero and on the Method screen — if you change the data flow, change that copy in the same commit.

## Model assumptions

Stated in the app on the Method screen, and worth repeating: the EBLR spread defaults to 2.65% and MCLR to 3.75%, EBLR resets quarterly and MCLR annually, and past the current month the model holds the repo rate flat rather than forecasting. Your real spread is in your sanction letter; a spread 0.25% off moves a 20-year result by roughly a year. An enter-your-own-spread field is the next feature.
