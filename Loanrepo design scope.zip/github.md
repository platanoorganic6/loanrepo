repo: platanoorganic6/loanrepo
branch: main

## Last sync

date: 2026-09-11

### Updated in this project

- Supabase is live: schema + seed applied, credentials in `supabase-config.js`. Verified rates (13), examples (5), waitlist insert, and that RLS rejects anonymous writes to `loan_runs`.
- Added `index.html` — a single self-contained build for static hosting (Render: no build command, publish directory = repo root).

- Connected the repo. It is empty (no commits yet); this project is the starting point, so nothing was imported.
- Added the Supabase data layer: schema + RLS migration, seed data, client module, config stub.
- Wired the app to Supabase: Google + magic-link auth, saved runs, rate history and examples read from the database with a client-side fallback, waitlist, anonymous screen analytics.
- Dropped the "nothing is stored" claim for an accurate one, on the hero and the Method screen.

## Screen map

| Project screen | Repo files |
| --- | --- |
| Your loan (calculator + result) | `LoanRepo.dc.html`, `supabase-client.js` |
| Rate cycle | `LoanRepo.dc.html`, `supabase/seed.sql` (`repo_rates`) |
| Examples | `LoanRepo.dc.html`, `supabase/seed.sql` (`examples`) |
| Saved runs | `LoanRepo.dc.html`, `supabase/migrations/0001_init.sql` (`loan_runs`) |
| Method (assumptions + waitlist) | `LoanRepo.dc.html`, `README.md` |
| Visual system | `_ds/industry-0aee6b66-0396-4d31-a389-4f4990a07af6/` (linked design system) |
