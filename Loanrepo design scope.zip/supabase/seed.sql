-- LoanRepo — seed data. Safe to re-run.

insert into public.repo_rates (effective_date, rate) values
  ('2020-02-06', 5.15),
  ('2020-03-27', 4.40),
  ('2020-05-22', 4.00),
  ('2022-05-04', 4.40),
  ('2022-06-08', 4.90),
  ('2022-08-05', 5.40),
  ('2022-09-30', 5.90),
  ('2022-12-07', 6.25),
  ('2023-02-08', 6.50),
  ('2025-02-07', 6.25),
  ('2025-04-09', 6.00),
  ('2025-06-06', 5.50),
  ('2025-12-05', 5.25)
on conflict (effective_date) do update set rate = excluded.rate;

insert into public.examples (start_month, city, amount, tenure_years, note, sort_order, published) values
  ('2020-08', 'Bengaluru',  4000000, 20, 'Bought at the deep-COVID rate floor',      1, true),
  ('2021-06', 'Pune',       5000000, 20, 'Bought during the COVID housing rush',     2, true),
  ('2022-01', 'Hyderabad',  6500000, 20, 'Bought just before the hike cycle began',  3, true),
  ('2023-03', 'Mumbai',     7500000, 20, 'Bought right after the peak hike',         4, true),
  ('2024-06', 'Chennai',    5500000, 15, 'Bought during the two-year rate hold',     5, true)
on conflict do nothing;
