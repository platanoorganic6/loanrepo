-- LoanRepo — initial schema
-- Run with: supabase db push   (or paste into the SQL editor)

create extension if not exists "pgcrypto";

-- ─────────────────────────────────────────────────────────────────────────────
-- profiles: one row per auth user, created by trigger on signup
-- ─────────────────────────────────────────────────────────────────────────────
create table public.profiles (
  id          uuid primary key references auth.users on delete cascade,
  email       text,
  full_name   text,
  created_at  timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles: owner reads"   on public.profiles for select using (auth.uid() = id);
create policy "profiles: owner updates" on public.profiles for update using (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ─────────────────────────────────────────────────────────────────────────────
-- repo_rates: the RBI MPC decision history the engine walks. Public read.
-- Writes are service-role only (no insert/update/delete policy for anon).
-- ─────────────────────────────────────────────────────────────────────────────
create table public.repo_rates (
  effective_date date primary key,
  rate           numeric(4,2) not null check (rate > 0 and rate < 25),
  source         text not null default 'RBI MPC',
  note           text
);

alter table public.repo_rates enable row level security;
create policy "repo_rates: public read" on public.repo_rates for select using (true);

-- ─────────────────────────────────────────────────────────────────────────────
-- examples: the curated case-study library. Public read of published rows.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.examples (
  id           uuid primary key default gen_random_uuid(),
  start_month  text not null check (start_month ~ '^\d{4}-\d{2}$'),
  city         text not null,
  amount       numeric(14,2) not null check (amount > 0),
  tenure_years int not null check (tenure_years between 1 and 30),
  benchmark    text not null default 'EBLR' check (benchmark in ('EBLR','MCLR')),
  note         text,
  sort_order   int not null default 0,
  published    boolean not null default false,
  created_at   timestamptz not null default now()
);

alter table public.examples enable row level security;
create policy "examples: public read published"
  on public.examples for select using (published = true);

-- ─────────────────────────────────────────────────────────────────────────────
-- loan_runs: a borrower's saved calculation. Strictly owner-scoped.
-- inputs are the particulars; result is the computed snapshot at save time,
-- kept so a saved run still reads correctly after the engine changes.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.loan_runs (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users on delete cascade,
  label        text,
  start_month  text not null check (start_month ~ '^\d{4}-\d{2}$'),
  amount       numeric(14,2) not null check (amount > 0),
  tenure_years int not null check (tenure_years between 1 and 30),
  benchmark    text not null check (benchmark in ('EBLR','MCLR')),
  result       jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now()
);

create index loan_runs_user_created_idx on public.loan_runs (user_id, created_at desc);

alter table public.loan_runs enable row level security;
create policy "loan_runs: owner reads"   on public.loan_runs for select using (auth.uid() = user_id);
create policy "loan_runs: owner inserts" on public.loan_runs for insert with check (auth.uid() = user_id);
create policy "loan_runs: owner updates" on public.loan_runs for update using (auth.uid() = user_id);
create policy "loan_runs: owner deletes" on public.loan_runs for delete using (auth.uid() = user_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- waitlist: email capture. Insert-only for everyone; nobody can read it back
-- through the anon key.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.waitlist (
  id         uuid primary key default gen_random_uuid(),
  email      text not null unique check (position('@' in email) > 1),
  source     text,
  created_at timestamptz not null default now()
);

alter table public.waitlist enable row level security;
create policy "waitlist: anyone joins" on public.waitlist for insert with check (true);

-- ─────────────────────────────────────────────────────────────────────────────
-- usage_events: anonymous product analytics. Insert-only, never readable via
-- the anon key. session_id is a client-generated random string, not an
-- identifier we can resolve back to a person. Never put loan amounts here.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.usage_events (
  id         bigserial primary key,
  event      text not null,
  props      jsonb not null default '{}'::jsonb,
  session_id text,
  created_at timestamptz not null default now()
);

create index usage_events_created_idx on public.usage_events (created_at desc);

alter table public.usage_events enable row level security;
create policy "usage_events: anyone inserts" on public.usage_events for insert with check (true);
