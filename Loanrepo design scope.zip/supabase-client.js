/* LoanRepo — Supabase data layer.
   Loads after supabase-js and supabase-config.js. Exposes window.LoanRepoDB.

   Every method degrades: with no credentials configured, reads return null and
   writes resolve to {ok:false, reason:'not-configured'} so the app keeps
   working entirely client-side. */
(function () {
  var cfg = window.LOANREPO_SUPABASE || {};
  var lib = window.supabase;
  var enabled = !!(cfg.url && cfg.anonKey && lib && lib.createClient);
  var client = enabled ? lib.createClient(cfg.url, cfg.anonKey) : null;

  function sessionId() {
    try {
      var k = "loanrepo.sid", v = localStorage.getItem(k);
      if (!v) {
        v = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
        localStorage.setItem(k, v);
      }
      return v;
    } catch (e) { return null; }
  }

  var DB = {
    enabled: enabled,
    client: client,

    /* ── auth ─────────────────────────────────────────────────────────── */
    onAuth: function (cb) {
      if (!enabled) { cb(null); return function () {}; }
      client.auth.getSession().then(function (r) {
        cb((r.data && r.data.session && r.data.session.user) || null);
      });
      var sub = client.auth.onAuthStateChange(function (_e, session) {
        cb((session && session.user) || null);
      });
      return function () { sub.data.subscription.unsubscribe(); };
    },
    signInEmail: function (email) {
      if (!enabled) return Promise.resolve({ ok: false, reason: "not-configured" });
      return client.auth
        .signInWithOtp({ email: email, options: { emailRedirectTo: window.location.href } })
        .then(function (r) { return { ok: !r.error, error: r.error && r.error.message }; });
    },
    signInGoogle: function () {
      if (!enabled) return Promise.resolve({ ok: false, reason: "not-configured" });
      return client.auth
        .signInWithOAuth({ provider: "google", options: { redirectTo: window.location.href } })
        .then(function (r) { return { ok: !r.error, error: r.error && r.error.message }; });
    },
    signOut: function () {
      if (!enabled) return Promise.resolve({ ok: false });
      return client.auth.signOut().then(function () { return { ok: true }; });
    },

    /* ── reference data ───────────────────────────────────────────────── */
    // → [{d:"2020-02-06", r:5.15}, …] in the engine's own shape, or null.
    fetchRepoHistory: function () {
      if (!enabled) return Promise.resolve(null);
      return client
        .from("repo_rates").select("effective_date, rate").order("effective_date")
        .then(function (r) {
          if (r.error || !r.data || !r.data.length) return null;
          return r.data.map(function (row) {
            return { d: row.effective_date, r: Number(row.rate) };
          });
        })
        .catch(function () { return null; });
    },
    // → [{date:"2021-06", city, amt, ten, note}, …] or null.
    fetchExamples: function () {
      if (!enabled) return Promise.resolve(null);
      return client
        .from("examples")
        .select("start_month, city, amount, tenure_years, note")
        .eq("published", true).order("sort_order")
        .then(function (r) {
          if (r.error || !r.data || !r.data.length) return null;
          return r.data.map(function (row) {
            return {
              date: row.start_month, city: row.city,
              amt: Number(row.amount), ten: row.tenure_years, note: row.note
            };
          });
        })
        .catch(function () { return null; });
    },

    /* ── saved runs (owner-scoped by RLS) ─────────────────────────────── */
    saveRun: function (run) {
      if (!enabled) return Promise.resolve({ ok: false, reason: "not-configured" });
      return client.auth.getUser().then(function (u) {
        var user = u.data && u.data.user;
        if (!user) return { ok: false, reason: "signed-out" };
        return client.from("loan_runs").insert({
          user_id: user.id,
          label: run.label || null,
          start_month: run.start_month,
          amount: run.amount,
          tenure_years: run.tenure_years,
          benchmark: run.benchmark,
          result: run.result || {}
        }).then(function (r) { return { ok: !r.error, error: r.error && r.error.message }; });
      });
    },
    listRuns: function () {
      if (!enabled) return Promise.resolve([]);
      return client
        .from("loan_runs")
        .select("id, label, start_month, amount, tenure_years, benchmark, result, created_at")
        .order("created_at", { ascending: false }).limit(50)
        .then(function (r) { return r.error ? [] : r.data; })
        .catch(function () { return []; });
    },
    deleteRun: function (id) {
      if (!enabled) return Promise.resolve({ ok: false });
      return client.from("loan_runs").delete().eq("id", id)
        .then(function (r) { return { ok: !r.error }; });
    },

    /* ── waitlist ─────────────────────────────────────────────────────── */
    joinWaitlist: function (email, source) {
      if (!enabled) return Promise.resolve({ ok: false, reason: "not-configured" });
      return client.from("waitlist").insert({ email: email, source: source || "app" })
        .then(function (r) {
          if (r.error && r.error.code === "23505") return { ok: true, duplicate: true };
          return { ok: !r.error, error: r.error && r.error.message };
        });
    },

    /* ── analytics: anonymous, never loan amounts ─────────────────────── */
    track: function (event, props) {
      if (!enabled) return;
      client.from("usage_events")
        .insert({ event: event, props: props || {}, session_id: sessionId() })
        .then(function () {}, function () {});
    }
  };

  window.LoanRepoDB = DB;
})();
