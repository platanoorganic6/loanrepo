-- LoanRepo — tracking, check-ins, and the paid tier.
-- Run after 0001_init.sql.

-- ─────────────────────────────────────────────────────────────────────────────
-- loan_runs becomes tracked_loans: the same particulars, now a named thing a
-- borrower returns to rather than a one-off snapshot. Rename keeps the RLS
-- policies and the index; they are renamed below only for legibility.
-- ─────────────────────────────────────────────────────────────────────────────
alter table public.loan_runs rename to tracked_loans;

alter table public.tracked_loans
  add column if not exists name     text,
  add column if not exists spread   numeric(4,2),
  add column if not exists archived boolean not null default false;

update public.tracked_loans set name = coalesce(name, label) where name is null;

alter policy "loan_runs: owner reads"   on public.tracked_loans rename to "tracked_loans: owner reads";
alter policy "loan_runs: owner inserts" on public.tracked_loans rename to "tracked_loans: owner inserts";
alter policy "loan_runs: owner updates" on public.tracked_loans rename to "tracked_loans: owner updates";
alter policy "loan_runs: owner deletes" on public.tracked_loans rename to "tracked_loans: owner deletes";

-- ─────────────────────────────────────────────────────────────────────────────
-- subscriptions: one row per user. Only the service role writes this — the
-- Razorpay webhook is the single source of truth, so a client cannot grant
-- itself the paid tier.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.subscriptions (
  user_id                 uuid primary key references auth.users on delete cascade,
  plan                    text not null default 'free' check (plan in ('free','pro')),
  status                  text not null default 'inactive'
                            check (status in ('inactive','active','halted','cancelled','past_due')),
  razorpay_customer_id    text,
  razorpay_subscription_id text unique,
  current_period_end      timestamptz,
  updated_at              timestamptz not null default now()
);

alter table public.subscriptions enable row level security;
create policy "subscriptions: owner reads" on public.subscriptions for select using (auth.uid() = user_id);
-- deliberately no insert/update/delete policy: writes are service-role only.

create or replace function public.is_pro(uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.subscriptions
    where user_id = uid and plan = 'pro' and status = 'active'
      and (current_period_end is null or current_period_end > now())
  );
$$;

-- ─────────────────────────────────────────────────────────────────────────────
-- The free tier is one tracked loan. Enforced here, not in the client, so the
-- gate holds even against someone calling the API directly.
-- ─────────────────────────────────────────────────────────────────────────────
create or replace function public.enforce_loan_limit()
returns trigger language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if public.is_pro(new.user_id) then return new; end if;
  select count(*) into n from public.tracked_loans
   where user_id = new.user_id and archived = false;
  if n >= 1 then
    raise exception 'free_tier_loan_limit'
      using hint = 'The free tier tracks one loan. Upgrade to track more.';
  end if;
  return new;
end;
$$;

create trigger tracked_loans_limit
  before insert on public.tracked_loans
  for each row execute function public.enforce_loan_limit();

-- ─────────────────────────────────────────────────────────────────────────────
-- check_ins: what the borrower actually observed on their statement, logged
-- against a tracked loan over time. This is the record the year-in-review and
-- the post-MPC digest read from.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.check_ins (
  id               uuid primary key default gen_random_uuid(),
  loan_id          uuid not null references public.tracked_loans on delete cascade,
  user_id          uuid not null references auth.users on delete cascade,
  observed_on      date not null default current_date,
  effective_rate   numeric(5,2) check (effective_rate > 0 and effective_rate < 30),
  emi              numeric(12,2) check (emi > 0),
  outstanding      numeric(14,2) check (outstanding >= 0),
  remaining_months int check (remaining_months between 0 and 480),
  outcome          text not null default 'unsure'
                     check (outcome in ('tenure_extended','emi_changed','no_change','unsure')),
  note             text,
  created_at       timestamptz not null default now()
);

create index check_ins_loan_idx on public.check_ins (loan_id, observed_on desc);

alter table public.check_ins enable row level security;
create policy "check_ins: owner reads"   on public.check_ins for select using (auth.uid() = user_id);
create policy "check_ins: owner inserts" on public.check_ins for insert with check (auth.uid() = user_id);
create policy "check_ins: owner updates" on public.check_ins for update using (auth.uid() = user_id);
create policy "check_ins: owner deletes" on public.check_ins for delete using (auth.uid() = user_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- payment_events: raw Razorpay webhook payloads, for idempotency and audit.
-- Service-role only in both directions.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.payment_events (
  id         bigserial primary key,
  event_id   text unique,
  event      text not null,
  payload    jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.payment_events enable row level security;
-- no policies: unreachable with the anon key.

-- ─────────────────────────────────────────────────────────────────────────────
-- digest_log: which loan got which post-MPC digest, so a retry or a double
-- schedule does not email anyone twice.
-- ─────────────────────────────────────────────────────────────────────────────
create table public.digest_log (
  id         bigserial primary key,
  loan_id    uuid not null references public.tracked_loans on delete cascade,
  digest_key text not null,
  sent_at    timestamptz not null default now(),
  unique (loan_id, digest_key)
);

alter table public.digest_log enable row level security;
-- no policies: service-role only.
