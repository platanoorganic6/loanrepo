-- LoanRepo — one-time ebook purchases.
-- Run after 0002_tracking_and_billing.sql.

create table public.purchases (
  id                 uuid primary key default gen_random_uuid(),
  email              text not null check (position('@' in email) > 1),
  user_id            uuid references auth.users on delete set null,
  product            text not null default 'ebook',
  amount_paise       int not null check (amount_paise > 0),
  status             text not null default 'created'
                       check (status in ('created','paid','failed','refunded')),
  razorpay_order_id  text unique,
  razorpay_payment_id text,
  download_token     uuid not null default gen_random_uuid(),
  download_count     int not null default 0,
  delivered_at       timestamptz,
  created_at         timestamptz not null default now()
);

create index purchases_email_idx on public.purchases (email, created_at desc);

alter table public.purchases enable row level security;

-- A signed-in buyer can see their own purchases. Everything else — creating a
-- purchase, marking it paid, reading the download token — happens service-side,
-- so a client can never mint itself a paid row.
create policy "purchases: owner reads"
  on public.purchases for select
  using (auth.uid() = user_id);
