-- LoanRepo — personalised ebook editions.
-- Run after 0003_ebook_purchases.sql.
--
-- The buyer's loan figures travel with the purchase so fulfilment can email a
-- copy written against their own loan rather than the generic edition. This is
-- the query string the book reads, not a second copy of the loan record.

alter table public.purchases
  add column if not exists loan_query text;

comment on column public.purchases.loan_query is
  'Query string for the personalised edition of the book, e.g. amount=5000000&start=Jun+2021&…. Null means the buyer had not run their loan, so the general edition is sent.';
