// mpc-digest — emails tracked-loan holders after a repo rate change, and again
// when the change is due to reach their own loan.
//
// Two things happen on each run:
//   1. If repo_rates gained a row since the last run, every tracked loan gets a
//      "the rate moved" note saying when it reaches them specifically.
//   2. Any loan whose own reset date falls in the next 7 days gets a
//      "check your statement this week" note.
//
// digest_log makes both idempotent, so a double schedule or a retry cannot
// email anyone twice.
//
// Deploy:   supabase functions deploy mpc-digest --no-verify-jwt
// Secrets:  supabase secrets set RESEND_API_KEY=... DIGEST_FROM="LoanRepo <hello@yourdomain>" APP_URL=https://...
// Schedule: Supabase → Integrations → Cron → daily, e.g. 30 3 * * *
//           (or: select cron.schedule('mpc-digest','30 3 * * *', $$ ... $$);)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const FROM = Deno.env.get("DIGEST_FROM") ?? "LoanRepo <hello@loanrepo.in>";
const APP_URL = Deno.env.get("APP_URL") ?? "https://loanrepo.in";

const admin = createClient(SUPABASE_URL, SERVICE_KEY);

const addMonths = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth() + n, d.getDate());
const monthsBetween = (a: Date, b: Date) =>
  (b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth());
const fmt = (d: Date) => d.toLocaleDateString("en-IN", { month: "long", year: "numeric" });

async function send(to: string, subject: string, lines: string[]) {
  const body = lines.map((l) => (l ? `<p style="margin:0 0 14px">${l}</p>` : "")).join("");
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: FROM,
      to,
      subject,
      html:
        `<div style="font-family:Barlow,system-ui,sans-serif;font-size:15px;line-height:1.6;color:#1d1f20;max-width:560px">` +
        body +
        `<p style="margin:24px 0 0"><a href="${APP_URL}" style="color:#41618a">Open LoanRepo</a></p>` +
        `<p style="margin:20px 0 0;font-size:12px;color:#6b6f73">You get this because you track a loan on LoanRepo. We send nothing else.</p></div>`,
    }),
  });
  if (!res.ok) console.error("resend failed", await res.text());
  return res.ok;
}

// Has the borrower already had this exact digest?
async function alreadySent(loanId: string, key: string) {
  const { data } = await admin
    .from("digest_log")
    .select("id")
    .eq("loan_id", loanId)
    .eq("digest_key", key)
    .maybeSingle();
  return !!data;
}

Deno.serve(async () => {
  const today = new Date();
  let sent = 0;

  const { data: rates } = await admin
    .from("repo_rates")
    .select("effective_date, rate")
    .order("effective_date", { ascending: false })
    .limit(2);
  const latest = rates?.[0];
  const previous = rates?.[1];

  const { data: loans } = await admin
    .from("tracked_loans")
    .select("id, user_id, name, start_month, amount, tenure_years, benchmark")
    .eq("archived", false);
  if (!loans?.length) return new Response(JSON.stringify({ sent: 0 }), { status: 200 });

  // Email addresses come from profiles, not from auth directly.
  const { data: profiles } = await admin
    .from("profiles")
    .select("id, email")
    .in("id", [...new Set(loans.map((l) => l.user_id))]);
  const emailOf = new Map((profiles ?? []).map((p) => [p.id, p.email]));

  for (const loan of loans) {
    const to = emailOf.get(loan.user_id);
    if (!to) continue;

    const [y, m] = String(loan.start_month).split("-").map(Number);
    const start = new Date(y, m - 1, 15);
    const resetN = loan.benchmark === "MCLR" ? 12 : 3;
    const elapsed = Math.max(monthsBetween(start, today), 0);
    const nextReset = addMonths(start, Math.ceil((elapsed + 0.001) / resetN) * resetN);
    const daysToReset = Math.round((nextReset.getTime() - today.getTime()) / 86400000);
    const label = loan.name || `${loan.start_month} loan`;

    // 1. A rate decision landed since the last digest.
    if (latest) {
      const key = `rate:${latest.effective_date}`;
      const decided = new Date(latest.effective_date);
      const age = (today.getTime() - decided.getTime()) / 86400000;
      if (age >= 0 && age <= 30 && !(await alreadySent(loan.id, key))) {
        const dir = previous
          ? Number(latest.rate) > Number(previous.rate) ? "rose" : "fell"
          : "moved";
        const bps = previous
          ? Math.round(Math.abs(Number(latest.rate) - Number(previous.rate)) * 100)
          : null;
        const ok = await send(to, `The repo rate ${dir} — what it means for ${label}`, [
          `The RBI repo rate ${dir}${bps ? ` by ${bps} bps` : ""} to <b>${Number(latest.rate).toFixed(2)}%</b>, effective ${new Date(latest.effective_date).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}.`,
          `That decision is national. The date it reaches <b>${label}</b> is yours: your ${resetN === 12 ? "annual" : "quarterly"} reset falls on or about <b>${fmt(nextReset)}</b>.`,
          dir === "rose"
            ? `If your EMI does not change at that reset, your tenure absorbed it instead. That is the default, and your statement will not say so in those words.`
            : `A cut does not automatically shorten your loan. Unless you ask, banks usually apply it to tenure — which is the good direction, but worth confirming.`,
          `When your statement for that month arrives, log what it actually says. It takes a minute and it is the only record that survives a change to our assumptions.`,
        ]);
        if (ok) {
          await admin.from("digest_log").insert({ loan_id: loan.id, digest_key: key });
          sent++;
        }
      }
    }

    // 2. This loan's own reset is a week out.
    if (daysToReset >= 0 && daysToReset <= 7) {
      const key = `reset:${nextReset.toISOString().slice(0, 7)}`;
      if (!(await alreadySent(loan.id, key))) {
        const ok = await send(to, `${label} resets this week`, [
          `<b>${label}</b> reaches a scheduled rate reset around <b>${fmt(nextReset)}</b>.`,
          `Two things to check on the statement that follows: whether the effective rate moved, and whether your remaining tenure moved with it. If the EMI is unchanged and the term grew, the rate cycle took the difference.`,
          `If the numbers do not reconcile, LoanRepo drafts a message to your bank with your own figures already in it.`,
        ]);
        if (ok) {
          await admin.from("digest_log").insert({ loan_id: loan.id, digest_key: key });
          sent++;
        }
      }
    }
  }

  return new Response(JSON.stringify({ sent }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
