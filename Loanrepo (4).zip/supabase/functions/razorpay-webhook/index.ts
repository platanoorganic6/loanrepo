// razorpay-webhook — the only thing that may grant or revoke the paid plan.
//
// Verifies the HMAC signature before trusting anything, stores each event for
// idempotency, then maps the Razorpay subscription state onto our own.
//
// Deploy:  supabase functions deploy razorpay-webhook --no-verify-jwt
//          (--no-verify-jwt is required: Razorpay calls this, not a user.)
// Secrets: supabase secrets set RAZORPAY_WEBHOOK_SECRET=...
// Razorpay → Settings → Webhooks → add the function URL and subscribe to:
//   subscription.activated, subscription.charged, subscription.halted,
//   subscription.cancelled, subscription.completed, subscription.pending

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const WEBHOOK_SECRET = Deno.env.get("RAZORPAY_WEBHOOK_SECRET")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function verify(raw: string, signature: string): Promise<boolean> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(WEBHOOK_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw));
  const expected = Array.from(new Uint8Array(mac))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  if (expected.length !== signature.length) return false;
  // Constant-time compare.
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ signature.charCodeAt(i);
  return diff === 0;
}

// Razorpay subscription status → (our plan, our status)
const MAP: Record<string, { plan: string; status: string }> = {
  active: { plan: "pro", status: "active" },
  authenticated: { plan: "free", status: "inactive" },
  pending: { plan: "pro", status: "past_due" },
  halted: { plan: "free", status: "halted" },
  cancelled: { plan: "free", status: "cancelled" },
  completed: { plan: "free", status: "cancelled" },
  expired: { plan: "free", status: "cancelled" },
};

Deno.serve(async (req) => {
  const raw = await req.text();
  const signature = req.headers.get("x-razorpay-signature") || "";

  if (!signature || !(await verify(raw, signature))) {
    return new Response("invalid signature", { status: 401 });
  }

  const body = JSON.parse(raw);
  const event: string = body.event ?? "";
  const sub = body.payload?.subscription?.entity;
  if (!sub?.id) return new Response("ignored", { status: 200 });

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  // Idempotency: Razorpay retries, and a double-grant is a real bug.
  const eventId = req.headers.get("x-razorpay-event-id") || `${event}:${sub.id}:${sub.status}`;
  const { error: dupe } = await admin
    .from("payment_events")
    .insert({ event_id: eventId, event, payload: body });
  if (dupe && dupe.code === "23505") return new Response("duplicate", { status: 200 });

  const userId = sub.notes?.supabase_user_id;
  if (!userId) {
    console.error("subscription without supabase_user_id note", sub.id);
    return new Response("no user", { status: 200 });
  }

  const mapped = MAP[sub.status] ?? { plan: "free", status: "inactive" };
  const periodEnd = sub.current_end ? new Date(sub.current_end * 1000).toISOString() : null;

  const { error } = await admin.from("subscriptions").upsert({
    user_id: userId,
    plan: mapped.plan,
    status: mapped.status,
    razorpay_customer_id: sub.customer_id ?? null,
    razorpay_subscription_id: sub.id,
    current_period_end: periodEnd,
    updated_at: new Date().toISOString(),
  });

  if (error) {
    console.error("subscription upsert failed", error);
    return new Response("error", { status: 500 });
  }

  return new Response("ok", { status: 200 });
});
