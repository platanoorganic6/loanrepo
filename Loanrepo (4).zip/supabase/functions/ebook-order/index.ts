// ebook-order — creates a Razorpay one-time order for the ebook.
//
// No auth required: the buyer gives an email and nothing else. The order is
// recorded as 'created'; only the webhook may mark it paid.
//
// Deploy:  supabase functions deploy ebook-order --no-verify-jwt
// Secrets: RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, EBOOK_PRICE_PAISE (e.g. 19900)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const KEY_ID = Deno.env.get("RAZORPAY_KEY_ID")!;
const KEY_SECRET = Deno.env.get("RAZORPAY_KEY_SECRET")!;
const PRICE = Number(Deno.env.get("EBOOK_PRICE_PAISE") ?? "29900");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const { email, loanQuery } = await req.json().catch(() => ({ email: "" }));
  if (!email || !String(email).includes("@")) return json({ error: "invalid_email" }, 400);

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const auth = "Basic " + btoa(`${KEY_ID}:${KEY_SECRET}`);

  const res = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({
      amount: PRICE,
      currency: "INR",
      notes: { product: "ebook", email },
    }),
  });
  const order = await res.json();
  if (!res.ok) {
    console.error("razorpay order failed", order);
    return json({ error: order?.error?.description ?? "razorpay_error" }, 502);
  }

  await admin.from("purchases").insert({
    email,
    product: "ebook",
    amount_paise: PRICE,
    status: "created",
    razorpay_order_id: order.id,
    // Carried through to fulfilment so the buyer receives a copy written
    // against their own loan rather than the generic edition.
    loan_query: typeof loanQuery === "string" && loanQuery ? loanQuery.slice(0, 2000) : null,
  });

  return json({ order_id: order.id, amount: PRICE, key_id: KEY_ID });
});
