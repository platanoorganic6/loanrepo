// ebook-webhook — the only thing that marks an ebook purchase paid, and the
// only thing that sends the download link.
//
// Verifies the Razorpay HMAC, flips the purchase to 'paid', then emails a
// time-limited signed URL to the file in Supabase Storage.
//
// Deploy:  supabase functions deploy ebook-webhook --no-verify-jwt
// Secrets: RAZORPAY_WEBHOOK_SECRET, RESEND_API_KEY, DIGEST_FROM, APP_URL
// Storage: create a PRIVATE bucket "ebook" and upload the PDF as
//          "the-quiet-years.pdf". Private matters — a public bucket makes the
//          paywall decorative.
// Razorpay → Webhooks → add this URL for: order.paid, payment.captured

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const WEBHOOK_SECRET = Deno.env.get("RAZORPAY_WEBHOOK_SECRET")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const FROM = Deno.env.get("DIGEST_FROM") ?? "LoanRepo <hello@loanrepo.in>";
const APP_URL = Deno.env.get("APP_URL") ?? "https://loanrepo.in";

const BUCKET = "ebook";
const OBJECT = "the-quiet-years.pdf";
const LINK_TTL = 60 * 60 * 24 * 14; // fourteen days

async function verify(raw: string, signature: string) {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(WEBHOOK_SECRET),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"],
  );
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw));
  const expected = Array.from(new Uint8Array(mac)).map((b) => b.toString(16).padStart(2, "0")).join("");
  if (expected.length !== signature.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ signature.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req) => {
  const raw = await req.text();
  const signature = req.headers.get("x-razorpay-signature") || "";
  if (!signature || !(await verify(raw, signature))) {
    return new Response("invalid signature", { status: 401 });
  }

  const body = JSON.parse(raw);
  const payment = body.payload?.payment?.entity;
  const orderId = payment?.order_id ?? body.payload?.order?.entity?.id;
  if (!orderId) return new Response("ignored", { status: 200 });

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  const { data: purchase } = await admin
    .from("purchases").select("*").eq("razorpay_order_id", orderId).maybeSingle();
  if (!purchase) return new Response("unknown order", { status: 200 });
  if (purchase.status === "paid" && purchase.delivered_at) {
    return new Response("already delivered", { status: 200 }); // idempotent
  }

  const { data: signed, error: signErr } = await admin.storage
    .from(BUCKET).createSignedUrl(OBJECT, LINK_TTL);
  if (signErr || !signed) {
    console.error("signing failed", signErr);
    return new Response("storage error", { status: 500 });
  }

  // Buyers who ran their loan before paying get the edition written against it.
  // The book renders from the query string, so no second PDF has to be built.
  const personalUrl = purchase.loan_query
    ? `${APP_URL}/Ebook.html?${purchase.loan_query}`
    : null;

  const html = personalUrl
    ? `<div style="font-family:Barlow,system-ui,sans-serif;font-size:15px;line-height:1.6;color:#1d1f20;max-width:560px">
<p style="margin:0 0 14px">Thank you — here is your copy of <b>The Quiet Years</b>, written against the loan you ran.</p>
<p style="margin:0 0 20px"><a href="${personalUrl}" style="color:#41618a">Open your personalised edition</a></p>
<p style="margin:0 0 14px">Chapter one opens on your own tenure drift, chapter eight works the prepayment arithmetic on your actual balance, and chapter fifteen lists your four reset dates. Print it from your browser to keep a PDF.</p>
<p style="margin:0 0 20px">The generic edition is here too, if you would rather have the plain file: <a href="${signed.signedUrl}" style="color:#41618a">download the PDF</a> (link good for fourteen days).</p>
<p style="margin:0 0 14px">Anything wrong with either, reply to this email.</p>
<p style="margin:24px 0 0"><a href="${APP_URL}" style="color:#41618a">LoanRepo</a></p>
</div>`
    : `<div style="font-family:Barlow,system-ui,sans-serif;font-size:15px;line-height:1.6;color:#1d1f20;max-width:560px">
<p style="margin:0 0 14px">Thank you — here is your copy of <b>The Quiet Years</b>.</p>
<p style="margin:0 0 20px"><a href="${signed.signedUrl}" style="color:#41618a">Download the PDF</a></p>
<p style="margin:0 0 14px">The link works for fourteen days. Save the file somewhere you will find it again; chapter fifteen is the part worth returning to four times a year.</p>
<p style="margin:0 0 14px">One thing worth doing: run your loan at <a href="${APP_URL}" style="color:#41618a">loanrepo.in</a> and the worked examples in chapters eight and fifteen can be regenerated on your own figures. Reply to this email and we will send that edition too.</p>
<p style="margin:24px 0 0"><a href="${APP_URL}" style="color:#41618a">LoanRepo</a></p>
</div>`;

  const mail = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM, to: purchase.email, subject: "Your copy of The Quiet Years", html }),
  });
  if (!mail.ok) {
    console.error("resend failed", await mail.text());
    // Mark paid anyway — the money is taken; delivery can be retried by hand.
    await admin.from("purchases").update({
      status: "paid", razorpay_payment_id: payment?.id ?? null,
    }).eq("id", purchase.id);
    return new Response("paid, delivery failed", { status: 500 });
  }

  await admin.from("purchases").update({
    status: "paid",
    razorpay_payment_id: payment?.id ?? null,
    delivered_at: new Date().toISOString(),
  }).eq("id", purchase.id);

  return new Response("ok", { status: 200 });
});
