// razorpay-order — creates a Razorpay subscription for the signed-in user.
//
// The key secret lives only here. The browser gets back a subscription id and
// the public key id, which is all Checkout needs. It never sees the secret, and
// it never tells us the user is paid — only the webhook does that.
//
// Deploy:  supabase functions deploy razorpay-order
// Secrets: supabase secrets set RAZORPAY_KEY_ID=... RAZORPAY_KEY_SECRET=... RAZORPAY_PLAN_ID=...

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const KEY_ID = Deno.env.get("RAZORPAY_KEY_ID")!;
const KEY_SECRET = Deno.env.get("RAZORPAY_KEY_SECRET")!;
const PLAN_ID = Deno.env.get("RAZORPAY_PLAN_ID")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const jwt = (req.headers.get("Authorization") || "").replace("Bearer ", "");
  if (!jwt) return json({ error: "unauthorized" }, 401);

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const { data: userData, error: userErr } = await admin.auth.getUser(jwt);
  const user = userData?.user;
  if (userErr || !user) return json({ error: "unauthorized" }, 401);

  // Already paying? Hand back the existing subscription rather than a second one.
  const { data: existing } = await admin
    .from("subscriptions")
    .select("razorpay_subscription_id, status")
    .eq("user_id", user.id)
    .maybeSingle();

  if (existing?.razorpay_subscription_id && existing.status === "active") {
    return json({ subscription_id: existing.razorpay_subscription_id, key_id: KEY_ID });
  }

  const auth = "Basic " + btoa(`${KEY_ID}:${KEY_SECRET}`);

  const res = await fetch("https://api.razorpay.com/v1/subscriptions", {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({
      plan_id: PLAN_ID,
      total_count: 120,          // ten years of monthly cycles; cancel any time
      customer_notify: 1,
      notes: { supabase_user_id: user.id, email: user.email ?? "" },
    }),
  });

  const sub = await res.json();
  if (!res.ok) {
    console.error("razorpay subscription create failed", sub);
    return json({ error: sub?.error?.description ?? "razorpay_error" }, 502);
  }

  // Record it as inactive. Only the webhook promotes it to active.
  await admin.from("subscriptions").upsert({
    user_id: user.id,
    plan: "free",
    status: "inactive",
    razorpay_subscription_id: sub.id,
    updated_at: new Date().toISOString(),
  });

  return json({ subscription_id: sub.id, key_id: KEY_ID });
});
